rango = reversed(range(1, 100))

for i in rango:
    print(i)
